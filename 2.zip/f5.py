from pyrogram import Client,filters
import asyncio,random,threading,json

id,haah = 15551290 , "52541a59f55c6f54678a4ec33e708e0f"
admins = (1078349914,1653924870)
comm = (".زق", ".الحسابات",".ريك",".ثرد",".كم",".ري",".اسرق",".كيل")


def savej(J,F):
	with open(F, 'w') as outfile: outfile.write(json.dumps(J))
	
def getk(F):
		with open(F) as json_file:
			data = json.load(json_file)
			return data


st =  getk('st')
re = st["re"]
jh =""" السلام عليكم 🖐ببوت سبام الريكشنات الاوامر حقت البوت : 

.زق : لبدا سبام الريكشنات

.كيل : ل ايقاف السبام

.ريك : لوضع ايموجي مخصص للريكشنات (الاساسي ❤)

.الحسابات : لاظهار عدد و معلومات الحسابات بل بوت

.ثرد : لوضع ثردينق محدد   (الاساسي 5)

.كم : لوضع الحد لعدد الرسائل التي سوف يتم الزق عليها  (الاساسي 10000) 

.ري : عشان تسوي ريستارت للملف مدري السيرفر

.اسرق : عشان تسرق 200 عضو من جروب محدد (ال 200 عضو رح ينضافو للجروب الي سويت فيه الامر)


+ لازم تكون ادمن بل بوت عشان تستخدمه 🥱


صاحب البوت و مطوره : @Jrjeueu
rvrhu4u848484ub4تقعق٧٤٨قهقتتقخث٩ثخقنتقق٨ثخظصتصع٦٦٧٧٧٢ت٣ة
"""
bot = Client("c/bbot",api_id=id,api_hash=haah)
app1 = Client("c/cc",api_id=id,api_hash=haah)
app2 = Client("c/cc2",api_id=id,api_hash=haah)
app3 = Client("c/cc3",api_id=id,api_hash=haah)
app4 = Client("c/cc4",api_id=id,api_hash=haah)
app5 = Client("c/cc5",api_id=id,api_hash=haah)
#app6 = Client("c/cc6",api_id=id,api_hash=haah)
#app7 = Client("c/cc7",api_id=id,api_hash=haah)
#app8 = Client("c/cc8",api_id=id,api_hash=haah)
app9 = Client("c/cc9",api_id=id,api_hash=haah)
app10 = Client("c/cc10",api_id=id,api_hash=haah)
app11 = Client("c/cc11",api_id=id,api_hash=haah)
app1.start()

print(1)
app2.start()
app3.start()
print(3)
app4.start()
app5.start()
#app6.start()
print(6)
#app7.start()
#app8.start()
app9.start()
print(7)
app10.start()
print(8)
app11.start()
print(11)

i =  getk('i')
ch = i['ch']
yym = [app1,app2,app3,app4,app5,app9,app10,app11]
def ss(ch,m ):
    
    
    try:
    	st =  getk('st')
    	re = st["re"]
    	print(random.choice(yym).send_reaction(ch, m, re))
    except Exception as h:
    	print(h)
    	pass
		
		
def start():
		global i,ch
		for z in range(10000):
			i =  getk('i')
			savej(i,'i')
			print(i,z)
			
			ss(i["ch"],i['i']-z)
			if(i['sc'] == 0): break
						
def hi(): start()			
def start2():			
	for x in range(1) : x = threading.Thread(target=hi()).start()


def getch(url):
	try:		
		SSS ={}		
		j = str(url).split('t.me/')[1]	
		SSS["ch"] = j.split('/')[0]
		SSS["mid"] =  int(j.split('/')[1])
		SSS["S"] = 1
		return SSS
	except Exception as h:
		print(h)
		SSS ={}	
		SSS["S"] = 0
		return SSS
		
def rd(t):
	emij = ["❤","💩","🤬","🤯","👍","👎","🤮"]
	for hh in list(t):
		if hh in emij:
			st =  getk('st')
			st["re"] = hh
			savej(st,'st')
			return True
	return False
		

def getname(app):
	hi = {}
	
			
		
		
@bot.on_message(filters.command("help"))
def help_command(_, message): 
    bot.send_message(    chat_id=message.chat.id,    text=jh,    reply_to_message_id=message.message_id)
@bot.on_message(filters.command("start"))
def help_commiiand(_, message):
    bot.send_message(    chat_id=message.chat.id,    text=jh,    reply_to_message_id=message.message_id)

			
@bot.on_message() 
def log(_, message):
	print(message)
	text = False
	if (1 == 1 ):
		text = message.text
		print(text)
	if text :	
	    if '.زق'  in text or text in comm or '.ريك'  in text :
		    if message.from_user.id in admins :
   	   	   	   	if '.زق'  in text :
   	   	   	   		mm = getch(text)
   	   	   	   		print(mm)
   	   	   	   		if mm["S"] == 1 :
   	   	   	   			ch  = 	mm["ch"]
   	   	   	   			midd =  mm["mid"]
   	   	   	   			i =  getk('i')
   	   	   	   			i['i'] = midd
   	   	   	   			i['sc'] = 1
   	   	   	   			i['ch'] = ch
   	   	   	   			savej(i,'i')
   	   	   	   			st =  getk('st')
   	   	   	   			re = st["re"]
   	   	   	   			
   	   	   	   			bot.send_message(chat_id=message.chat.id,text=f"تم بدا الزق على الجروب ✅ \nالجروب : @{ch} \nايدي البدا : {midd} \nعدد الرسائل التي سوف يتم الزق عليها : 10000\nعدد الحسابات : 8\nالريكشن : {re}\nالثردينق : 50",reply_to_message_id=message.message_id);start2()
   	   	   	   		else:
   	   	   	   			bot.send_message(chat_id=message.chat.id,text="اكتب الامر زي الناس \n .زق رابط الرساله \nمثال :\n .زق http://t.me/ccc333/1",reply_to_message_id=message.message_id)
   	   	   	   	elif '.ريك' in text :
   	   	   	   		nn = rd(text)
   	   	   	   		if nn == False : bot.send_message(chat_id=message.chat.id,text="يا حبيبي  سوي الامر زي الناس 😑 \n مثال :\n .ريك ❤ \n الايموجيات المسموحه : (❤🤮👎👍🤯🤬💩) ",reply_to_message_id=message.message_id)
   	   	   	   		if nn == True :
   	   	   	   			st =  getk('st')
   	   	   	   			re = st["re"]
   	   	   	   			bot.send_message(chat_id=message.chat.id,text=f"تم وضعت الريكشن  {re}",reply_to_message_id=message.message_id)
   	   	   	   	elif '.كيل' in text :
   	   	   	   		i =  getk('i')
   	   	   	   		if i['sc'] == 1 :
   	   	   	   			i['sc']   = 0
   	   	   	   			ch = i["ch"]
   	   	   	   			savej(i,'i')
   	   	   	   			bot.send_message(chat_id=message.chat.id,text=f"تم طفيت السكرين حق  @{ch}",reply_to_message_id=message.message_id)
   	   	   	   		else:
   	   	   	   			bot.send_message(chat_id=message.chat.id,text=f"اصلن ما في سكرين شغال عشان توقفه",reply_to_message_id=message.message_id)



		    else:
		    	bot.send_message(chat_id=message.chat.id,text="يا ورع انت مو ادمن بل بوت",reply_to_message_id=message.message_id)

	
	


	
	


if __name__ == "__main__": bot.run()
	
			
		

		